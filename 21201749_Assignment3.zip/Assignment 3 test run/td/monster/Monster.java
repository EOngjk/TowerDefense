package td.monster;

import com.sun.org.apache.bcel.internal.generic.ARETURN;
import com.sun.org.apache.bcel.internal.generic.DRETURN;
import td.Block;
import java.util.List;
import td.tower.Tower;
/**
 * Monster class.
 * 
 * On each turn it moves to the right by one cell. If it steps on 
 * a tower (i.e., share the same coordinate as the tower), the tower
 * will be destroyed.
 * 
 * A monster reaches home will end the game. 
 * 
 * If a monster has health point 0 or negative, it cannot move anymore
 * and shall be removed from the game.
 * 
 * A monster shall return the last digit of its health as its symbol.
 * For example, if a monster has a health 10, it should return the character '0'
 * If a monster has a health of 31, it should return the character '1'
 * 
 * 
 * There are some methods to be included in this class. Yet, you need to 
 * deduce what methods are needed from other java files.
 * 
 * 
 */
public class Monster extends Block {
    //Monsters have their own health & symbols
    private int health;
    private char symbol;

    public Monster(int row, int col, int health){
        super(row, col);
        this.health = health;
        symbol = getSymbol();
    }

    public int getHealth(){
        return health;
    }

    @Override
    public void action(List<Block> blocks) {
        if (this.health <=0)
            this.remove();
        if (!this.isToRemove()){
            this.col++;
            if (blocks.size() > 0) {
                for (Block b : blocks) {
                    if (b instanceof Tower && b.getCol() == this.getCol() && b.getRow() == this.getRow())
                        b.remove();
                }
            }
        }
    }

    public void receiveDamage(int damage){
        this.health -= damage;
    }

    @Override
    public char getSymbol() {
        String symString = Integer.toString(this.getHealth());
        int symLength = symString.length();
        char sym = symString.charAt(symLength-1);
        return sym;
    }

    public String toString() {
        return "Monster " + getSymbol() + " [" + getHealth() + "]";
    }
}
