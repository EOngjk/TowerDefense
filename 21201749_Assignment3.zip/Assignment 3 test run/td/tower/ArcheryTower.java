package td.tower;

import java.util.List;
import td.monster.Monster;
import td.Block;

/**
 * Archery 
 * 
 * The archery tower will aim only one monster that has positive, non-zero 
 * health point. If there are multiple monster that are in range,
 * pick the one that is nearest to "home".
 * 
 * Propoerty of Archery tower:
 * Symbol : 'A'
 * Inital power: 5
 * Range : 3
 * cost : 5
 * upgrade power: 1 
 * upgrade cost: 2
 */
public class ArcheryTower extends Tower {
    private char symbol = 'A';
    public ArcheryTower(int row, int col){
        super(row, col, 5, 5, 2, 1, 3);
    }

    @Override
    public char getSymbol() {
        return symbol;
    }

    @Override
    public void action(List<Block> blocks) {
        //Find a monster that is in range and set it as a comparison
        Monster temp = null;

        if (blocks.size() > 0){
            for (Block b: blocks){
                if (b instanceof Monster && isInRange(b) && ((Monster) b).getHealth() > 0){
                    //First monster detected, assign the block to temp
                    if (temp == null)
                        temp = (Monster) b;
                    //Not first monster detected
                    //If it is closer to "home" then assign the block to temp
                    else if (b.getCol() > temp.getCol()) {
                        temp = (Monster) b;
                    }
                }
            }
        }

        //Archery tower does damage to the monster
        if (temp != null)
            temp.receiveDamage(getPower());
    }

}
