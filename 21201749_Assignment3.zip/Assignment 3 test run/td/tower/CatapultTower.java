package td.tower;

import td.Block;
import td.Game;
import td.monster.Monster;

import java.util.ArrayList;
import java.util.List;

/**
 * Catapult
 * 
 * A catapult works in the following way. It will target on
 * one monster among all monsters that are in range. When there
 * are more than one monsters in range, pick ANY monster with 
 * highest remaining health point.
 * 
 * Then, it hits the target monster and other monsters located in
 * its 8 neighthor adjacent cells. For example,
 * ----------------------
 * | a | b | c | e |
 * | d | f | g | h |
 * | i | j | k | l |  ...
 * | m | n | o | p |
 * ----------------------
 * * If g is the target monster, monsters <b, c, e, f, g, h, j, k, l>
 * will receive damage.
 * * If m is the target monster, monsters <i, j, m, n>
 * will receive damage.
 * 
 * Note: In the first example, even if monster b is out of the range 
 * of the Tower, as long as Tower can hit g, b will also receive damage.
 * 
 * Propoerty of Catapult:
 * Symbol : 'C'
 * Inital power: 4
 * Range : 6
 * cost : 7
 * upgrade power: 2 
 * upgrade cost: 3
 * 
 */
public class CatapultTower extends Tower {
    private final char symbol = 'C';
    public CatapultTower(int row, int col){
        super(row, col, 4, 7, 3, 2, 6);
    }

    public char getSymbol() {
        return symbol;
    }


    @Override
    public void action(List<Block> blocks) {
        //Attack the monster with the highest HP
        //Find a monster that is in range and set it as a comparison
        Monster temp = null;

        //Archery one
        if (blocks.size() > 0){
            for (Block b: blocks){
                if (b instanceof Monster && isInRange(b) && ((Monster) b).getHealth() > 0){
                    //First monster detected, assign the block to temp
                    if (temp == null){
                        temp = (Monster) b;
                    }
                    //Not first monster detected
                    //Check for the highest health point monster
                    else if (((Monster) b).getHealth() > temp.getHealth()) {
                        temp = (Monster) b;
                    }
                }
            }
        }

        if (temp != null){
            temp.receiveDamage(getPower());
            for (Block b: blocks){
                if (b instanceof Monster && isInRange(b) && ((Monster) b).getHealth() > 0){
                    if (Math.abs(b.getRow() - temp.getRow()) <= 1 && Math.abs(b.getCol() - temp.getCol()) <= 1)
                        ((Monster) b).receiveDamage(getPower());
                }
            }
        }
    }

    //Get the adjacentCells containing monsters

}
