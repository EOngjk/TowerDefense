package td;

import java.util.List;
import java.util.Scanner;

import td.monster.Monster;
import td.tower.*;
import static td.GUIDisplay.DisplayBlock.HEIGHT;
import static td.GUIDisplay.DisplayBlock.WIDTH;

/**
 * A View class. To display the information on screen and also
 * to take user's control.
 */
public class ConsoleDisplay implements Displayable {
    /**
     * The controller object game.
     */
    protected Game game;

    /**
     * Entry point. Don't touch
     */
    public static void main(String[] args) {
        new ConsoleDisplay();
    }

    /**
     * Constructor. To construct the game object and call game.run();
     */
    public ConsoleDisplay() {
        this.game = new Game(this);
        game.run();
    }

    @Override
    public void gameOver() {
        System.out.println("Game over!");
    }

    /**
     * To display the score, money, map and character on screen.
     */
    @Override
    public void display() {
        System.out.printf("Score: %d | Money: %d\n", this.game.getScore(), this.game.getMoney());

        //Displays map & character
        this.displayMap();
    }

    /**
     * To create a 2D array of symbols for respective blocks according to its coordinate.
     * If block is null (not tower or monster), the corresponding array value will be ' '.
     * Else, it will contain the symbol of the block (tower or monster)
     * @return
     */
    private char[][] symbolMap(){
        //create a 2D array to store the symbols
        char[][] symbolTM = new char[game.HEIGHT][game.WIDTH];

        //store ' ' in the 2D array
        for (int i = 0; i < this.game.HEIGHT; i++)
            for (int j = 0; j < this.game.WIDTH; j++)
                symbolTM[i][j] = ' ';

        //Update the 2D array with the blocks' symbol that are not null (Tower/monster)
        for (Block b: this.game.blocks)
            symbolTM[b.getRow()][b.getCol()] = b.getSymbol();
        return symbolTM;
    }

    /**
     * Prints the map of the game.
     */
    private void displayMap(){
        char[][] symbolTM = symbolMap();
        for (int i = 0; i < Game.WIDTH + 4; i++){
            System.out.print("-");
        }
        System.out.println();

        for (int i = 0; i < Game.HEIGHT; i++){
            for (int j = 0; j < Game.WIDTH; j++){
                System.out.print(symbolTM[i][j]);
            }
            System.out.println("oooo");
        }
    }


    /**
     * Prints the map WHEN option1() : View a monster/tower is called.
     * Prints the range of the tower with symbol '#' (Tower only)
     * Prints information of the block. (Tower and monster)
     *
     * @param block is the block that users want to inspect (Tower/Monster)
     */
    private void viewBlock(Block block){
        char[][] symbolViewBlock = symbolMap();

        //if block is ArcheryTower
        if (block instanceof ArcheryTower){
            for (int i = 0; i < Game.HEIGHT; i++){
                for (int j = 0; j < Game.WIDTH; j++){
                    ArcheryTower temp = new ArcheryTower(i,j);
                    if ( ((Tower)block).isInRange(temp))
                        if (symbolViewBlock[i][j] == ' ')
                            symbolViewBlock[i][j] = '#';
                }
            }
        }
        //if block is CatapultTower
        else if (block instanceof CatapultTower){
            for (int i = 0; i < Game.HEIGHT; i++){
                for (int j = 0; j < Game.WIDTH; j++){
                    CatapultTower temp = new CatapultTower(i,j);
                    if ( ((Tower)block).isInRange(temp))
                        if (symbolViewBlock[i][j] == ' ')
                            symbolViewBlock[i][j] = '#';
                }
            }
        }
        //if block is LaswerTower
        else if (block instanceof LaserTower){
            for (int i = 0; i < Game.HEIGHT; i++){
                for (int j = 0; j < Game.WIDTH; j++){
                    if (i == block.getRow() && j < block.getCol())
                        if (symbolViewBlock[i][j] == ' ')
                            symbolViewBlock[i][j] = '#';
                }
            }
        }

        for (int i = 0; i < Game.WIDTH + 4; i++){
            System.out.print("-");
        }
        System.out.println();

        for (int i = 0; i < Game.HEIGHT; i++){
            for (int j = 0; j < Game.WIDTH; j++){
                System.out.print(symbolViewBlock[i][j]);
            }
            System.out.println("oooo");
        }

        // Print information about the block, eg Tower [C] Power: 4 Upgrade cost: 3 / Monster 0 [10]
        if (block != null) {
            System.out.println(block);
        }
    }



    /**
     * To accept user input (build tower, upgrade tower, view blocks).
     *
     * This method has been done for you.
     * You should not modify it.
     * You are not allowed to modify it.
     */
    @Override
    public void userInput() {
        while (true) {
            Scanner scanner = new Scanner(System.in);
            printInstruction();
            try {
                switch (scanner.nextInt()) {
                    case 1:
                        option1();
                        break;
                    case 2:
                        option2();
                        break;
                    case 3:
                        option3();
                        break;
                    case 4:
                        return;
                    default:
                        throw new InvalidInputException("Invalid option! Pick only 1-4");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            display();
        }
    }

    /**
     * Given method.
     *
     * You are not supposed to change this method.
     * But you can change if you wish.
     */
    private void printInstruction() {
        System.out.println("Please pick one of the following: ");
        System.out.println("1. View a tower/monster");
        System.out.println("2. Build a new Tower");
        System.out.println("3. Upgrade a Tower");
        System.out.println("4. End a turn");
    }


    //Option 1: View a tower/monster
    private void option1(){
        try{
            System.out.println("Enter the coordinate of the tower/monster row followed by column");
            Scanner in = new Scanner(System.in);
            int row = in.nextInt();
            int col = in.nextInt();
            Block displayBlock = game.getBlockByLocation(row, col);
            // if there is something in this location, display that block
            if (displayBlock!=null) {
                this.viewBlock(displayBlock);
            } else {
                // print exception error
                throw new td.InvalidInputException();
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    //Option 2: Build a new Tower
    private void option2(){
        try{
            System.out.println("You can build the following towers:");
            System.out.println("1. ArcheryTower ($5); 2. LaserTower ($7);3. CatapultTower ($7)");
            Scanner in = new Scanner(System.in);
            int input = in.nextInt();

            System.out.println("Which row?");
            int row = in.nextInt();

            System.out.println("Which col?");
            int col = in.nextInt();

            //Check whether can build on that block
            if (!this.game.build(input, row, col)) {
                // print exception error
                throw new td.InvalidInputException("Sorry, the option is invalid. Please check if you have enough " +
                        "money. You can only build on a cell without any monster or tower. You cannot build on column 0 too!");
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    //Option 3: Upgrade a Tower
    private void option3(){
        try{
            Scanner in = new Scanner(System.in);
            System.out.print("Enter the row of your tower:");
            int row = in.nextInt();

            System.out.print("Enter the column of your tower:");
            int col = in.nextInt();
            if (!this.game.upgrade(row, col)){
                throw new td.InvalidInputException("Sorry, the option is invalid. Please check if you have enough money to " +
                        "upgrade and there is already a tower for you to upgrade.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
